%% Result 3 : Face vs non-face discrimination task on untrained AlexNet 
fontSize_title = 15; fontSize_label = 15; fontSize_legend = 12; 

N = 30;                                                                                                     % Number of random sampling
ratio_Tr_Te = 3;                                                                                            % Ratio of images in Train, Test set (Train : Test) = 2:1;
numFace_ratio = 3;                                                                                          % Number of range of FSI;
YTrain = [ones(nIMG/ratio_Tr_Te*(ratio_Tr_Te-1),1); zeros(nIMG/ratio_Tr_Te*(ratio_Tr_Te-1),1)];
YTest = [ones(nIMG/ratio_Tr_Te,1); zeros(nIMG/ratio_Tr_Te,1)];

act_M = Cell_act{2,1}; actMAT = reshape(permute(act_M(:,1:nCLS-1,:),[1,3,2]),numNeuron,(nCLS-1)*nIMG);
IND_face = Cell_IND{2,1}; IND_nface = find(sum(mean(act_M(:,1:nCLS-1,:),3)>mean(act_M(:,nCLS,:),3),2)==0);
SI = Cell_SI{2,1}; SI = SI(IND_face); [orderSI,order] = sort(SI); edge_FSI = [0.4,0.6,0.85,1]; 
numSample = length(order(find((orderSI>=edge_FSI(1))&(orderSI<edge_FSI(2)))));
ind_inc = [nIMG:nIMG:nIMG*(nCLS-2)]';

array_SVMaccu = zeros(N,5); array_SVMaccuFSI = zeros(N,numFace_ratio); array_rangeFSI = zeros(N,numFace_ratio);
tic
disp('%% SVM training ... (~ 1.5 min)')
for nn = 1:N
    if mod(nn,10) == 1; disp(['%%% Trial = ',num2str(nn),'/',num2str(N)]); end
    %% Split imageset into train/test set  
    iFace = randperm(nIMG,nIMG/ratio_Tr_Te); tmpiObject = randperm(nIMG,nIMG/(nCLS-2));
    tmpiObject_test = tmpiObject(1:nIMG/(nCLS-2)/ratio_Tr_Te); tmpiObject_train = tmpiObject(nIMG/(nCLS-2)/ratio_Tr_Te+1:end);
    iObject_test = ind_inc+repmat(tmpiObject_test,[size(ind_inc),1]); iObject_train = ind_inc+repmat(tmpiObject_train,[size(ind_inc),1]);
    indTest = [iFace iObject_test(:)']; indTrain = [setdiff([1:nIMG],iFace) iObject_train(:)'];
    
    %% Response
    % Conv 5 response
    XTrain_all = actMAT(:,indTrain); XTest1_all = actMAT(:,indTest); 
    
    % Face neuron response
    tmpIND_aface = IND_face(randperm(length(IND_face),1));
    XTrain_aface = actMAT(tmpIND_aface,indTrain); XTest_aface = actMAT(tmpIND_aface,indTest);
    XTrain_faceAll = actMAT(IND_face,indTrain); XTest_faceAll = actMAT(IND_face,indTest);
    
    % Non-face neuron response
    tmpIND_anface = IND_nface(randperm(length(IND_nface),1));
    tmpIND_nface = IND_nface(randperm(length(IND_nface),length(IND_face)));
    XTrain_anface = actMAT(tmpIND_anface,indTrain); XTest_anface = actMAT(tmpIND_anface,indTest);
    XTrain_nfaceAll = actMAT(tmpIND_nface,indTrain); XTest_nfaceAll = actMAT(tmpIND_nface,indTest);
    
    %% Train SVM & test
    % Conv 5 response
    Mdl = fitcecoc(XTrain_all',YTrain);
    YPredict = predict(Mdl,XTest1_all');
    array_SVMaccu(nn,1) = length(find(YTest == YPredict))./length(YTest);
    
    % Face neuron response
    Mdl = fitcecoc(XTrain_aface',YTrain);
    YPredict = predict(Mdl,XTest_aface');
    array_SVMaccu(nn,2) = length(find(YTest == YPredict))./length(YTest);
    Mdl = fitcecoc(XTrain_faceAll',YTrain);
    YPredict = predict(Mdl,XTest_faceAll');
    array_SVMaccu(nn,3) = length(find(YTest == YPredict))./length(YTest);
    
    % Non-face neuron response
    Mdl = fitcecoc(XTrain_anface',YTrain);
    YPredict = predict(Mdl,XTest_anface');
    array_SVMaccu(nn,4) = length(find(YTest == YPredict))./length(YTest);
    Mdl = fitcecoc(XTrain_nfaceAll',YTrain);
    YPredict = predict(Mdl,XTest_nfaceAll');
    array_SVMaccu(nn,5) = length(find(YTest == YPredict))./length(YTest);
    
    %% Train SVM & test across FSI range
    for ii = 1:numFace_ratio
        % face neuron
        ind_f = order(find((orderSI>=edge_FSI(ii))&(orderSI<edge_FSI(ii+1))));
        ind_f = ind_f(randperm(length(ind_f),numSample));
        
        Mdl = fitcecoc(XTrain_faceAll(ind_f,:)',YTrain);
        YPredict = predict(Mdl,XTest_faceAll(ind_f,:)');
        array_SVMaccuFSI(nn,ii) = length(find(YTest == YPredict))./length(YTest);
        array_rangeFSI(nn,ii) = mean(SI(ind_f));
    end
end
toc

%% Figure 3b-c : SVM performance (Single neuron vs Multiple neuron)
figure('units','normalized','outerposition',[0 0 0.5 1]);
subplot(2,1,1)
hold on; 
bar([1],mean(array_SVMaccu(:,2),1),'facecolor','r')
bar([2],mean(array_SVMaccu(:,4),1),'facecolor','w')
line([0.5 2.5],[0.5 0.5],'color','k','linestyle','--')
errorbar([1],mean(array_SVMaccu(:,2),1),std(array_SVMaccu(:,2),1),'k')
errorbar([2],mean(array_SVMaccu(:,4),1),std(array_SVMaccu(:,4),1),'k')
xlim([0.5 2.5]); xticks([1:2]); ylim([0.4 1]); ylabel('Correct ratio (%)','FontSize',fontSize_label);
xticklabels({'Face-neurons','Non-face neurons'});
title('Single neuron performance (Figure 3b)','FontSize',fontSize_label)
legend(['Face neurons (n = ',num2str(1),')'],['Non face neurons (n = ',num2str(1),')'],'Chance level','location','northeast','FontSize',fontSize_legend)

subplot(2,1,2)
hold on; 
bar([1],mean(array_SVMaccu(:,3),1),'facecolor','r')
bar([2],mean(array_SVMaccu(:,5),1),'facecolor','w')
line([0.5 2.5],[mean(array_SVMaccu(:,1),1) mean(array_SVMaccu(:,1),1)],'color','k','linestyle','-')
line([0.5 2.5],[0.5 0.5],'color','k','linestyle','--')
errorbar([1],mean(array_SVMaccu(:,3),1),std(array_SVMaccu(:,3),1),'k')
errorbar([2],mean(array_SVMaccu(:,5),1),std(array_SVMaccu(:,5),1),'k')
xlim([0.5 2.5]); xticks([1:2]); ylim([0.4 1.2]); ylabel('Correct ratio (%)','FontSize',fontSize_label);
xticklabels({'Face-neurons','Non-face neurons'});
title('Multiple neuron performance (Figure 3c)','FontSize',fontSize_label)
legend(['Face neurons (n = ',num2str(length(IND_face)),')'],['Non face neurons (n = ',num2str(length(IND_face)),')'],...
    ['All neurons (Conv5 : n = ',num2str(numNeuron),')'],'Chance level','location','northeast','FontSize',fontSize_legend)

%% Figure 3d : SVM performance across FSI 
figure('units','normalized','outerposition',[0.5 0.3 0.5 0.5]);
errorbar(mean(array_rangeFSI),mean(array_SVMaccuFSI,1),std(array_SVMaccuFSI,1),'-ro')
xlim([0.4 1]); ylim([0.6 0.9]); xlabel('FSI of face-neurons used in SVN','FontSize',fontSize_label); ylabel('Correct ratio','FontSize',fontSize_label);
title('SVM performance across FSI (Figure 3d)','FontSize',fontSize_label)