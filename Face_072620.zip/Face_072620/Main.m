%% Demo code ver. 07/26/2020
%==================================================================================================================================================
% Spontaneous generation of face recognition in untrained deep neural networks
% Baek S*, Song M*, Kim G, Jang J & Paik SB (* Equally contributed)
% link: https://www.biorxiv.org/content/10.1101/857466v1
% doi: 10.1101/857466
%
% Prerequirement 
% 1) MATLAB 2018b or later version is recommended.
% 2) Install deeplearning toolbox. 
%
% Output of the code
% Below results for permuted (randomized) AlexNet will
% be shown.
% 1) Face-selectivity in pre-trained / untrained AlexNet (Figure 1)
% 2) Preferred feature image on untrained AlexNet (Figure 2) 
% 3) Face vs non-face discrimination task on untrained AlexNet (Figure 3) 
% 4) Layer-dependent viewpoint invariance in untrained AlexNet (Figure 4-5) 
%
% Contacts : Seungdae Baek (seung7649@kaist.ac.kr)
%==================================================================================================================================================
close all;clc;clear;
rng(3)                                                      % fixed random seed for regenerating same result
toolbox_chk;                                                % checking matlab version and toolbox
tic
load('flg.mat')                                             % flag for runing each Figure

if flg1+flg2+flg3+flg4 > 0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% Setting parameters
    inpSize = 227;                                              % width ( or height of images )
    nIMG = 144;                                                 % number of images on each class in the dataset
    nCLS = 6;                                                   % number of total object classes in the dataset
    indFace = 1;                                                % index of face class in the dataset
    pThr = 0.001;                                               % p-value threshold of selective response
    layersSet = {'relu1', 'relu2', 'relu3', 'relu4', 'relu5'};	% names of feature extraction layers
    indLayer  = 5;                                              % index of target layer 
    ver = 1;                                                    % version of initialization 
                                                                %  1: LeCun / 2: He / 3: LeCun uniform / 4: He uniform                                                              
    stdArray = [0.5 1 1.5];                                     % std of gaussian kernel for randomly initialized network
    
    dirIMG = 'Dataset';                                         % set data directory list of class names
    dirList=dir(dirIMG); STR_LABEL = cell(1,nCLS);              % list of class names
    for ii = 1:nCLS
        tmp = split(dirList(ii+2).name,'_');
        STR_LABEL{ii} = tmp{2};
    end

    %% Step 1. Loading image dataset
    tic
    disp('Step1 : Loading image dataset ... (~ 20 sec)');
    imd = imageDatastore(dirIMG,'IncludeSubfolders',true,'LabelSource','foldernames');         % load image dataset
    imds = augmentedImageDatastore([inpSize inpSize 1],imd,'ColorPreprocessing','gray2rgb');   % resize image dataset
    IMG_M = zeros(inpSize,inpSize,3,nIMG*nCLS);
    for nn = 1:nIMG*nCLS
        IMG_temp  = imresize(double(imread(imd.Files{nn})), [inpSize inpSize]);
        IMG_M(:,:,:,nn) = repmat(IMG_temp,1,1,3);
    end
    toc

    %% Step 2. Loading pretrained Alexnet and permute kernel of Alexnet randomly
    tic
    disp('Step2: Loading pretrained Alexnet and permute kernel of Alexnet randomly ... (~ 5 sec)');
    net = alexent;                                                             % load pretrained Alexnet produced by Matlab 2018b
    net_rand = fun_Initializeweight(net,ver,1);                                             % random initialization of weight kernel on each layer
    Cell_net_var = cell(2,length(stdArray));
    for ii = 1:length(stdArray)
        Cell_net_var{1,ii} = fun_Initializeweight(net,ver,stdArray(ii));                    % random initialization across different weight variation
        Cell_net_var{2,ii} = fun_Initializeweight(net,ver+2,stdArray(ii));                  % random initialization across different weight variation with uniform distribution
    end
    Cell_net = {net;net_rand};
    toc
    
    %% Step 3. Measuring responses of neurons in the target layer
    tic
    disp('Step3: Measuring responses of neurons in the target layer ... (~ 40 sec)');
    act = activations(net,imds,layersSet{indLayer});                                                        % response of all neurons to all images on pretrained AlexNet
    act_rand = activations(net_rand,imds,layersSet{indLayer});                                              % response of all neurons to all images on untrained AlexNet
    numNeuron = numel(act)/nIMG/nCLS;
    
    act_M = zeros(numNeuron,nCLS,nIMG);
    act_rand_M = zeros(numNeuron,nCLS,nIMG);
    for ii = 1:nCLS
        act_M(:,ii,:) = reshape(act(:,:,:,(ii-1)*nIMG+1:(ii)*nIMG), numNeuron,nIMG);             % reshape response of all neurons to all images on pretrained AlexNet
        act_rand_M(:,ii,:) = reshape(act_rand(:,:,:,(ii-1)*nIMG+1:(ii)*nIMG),numNeuron,nIMG);    % reshape response of all neurons to all images on untrained AlexNet
    end
    Cell_act = {act_M;act_rand_M};
    
    Cell_act_var = cell(2,length(stdArray));
    for ii = 1:length(stdArray)
        net_var = Cell_net_var{1,ii}; net_var_uni = Cell_net_var{2,ii};                                                                       % load ramdomly intialized AlexNet with ii th standard deviation.
        act_var = activations(net_var,imds,layersSet{indLayer});  act_var_uni = activations(net_var_uni,imds,layersSet{indLayer});            % response of all neurons to all images on ramdomly intialized AlexNet                        
        act_var_M = zeros(numNeuron,nCLS,nIMG); act_varUni_M = zeros(numNeuron,nCLS,nIMG);
        for jj = 1:nCLS
            act_var_M(:,jj,:) = reshape(act_var(:,:,:,(jj-1)*nIMG+1:(jj)*nIMG),numNeuron,nIMG);                                    % reshape response of all neurons to all images on untrained AlexNet
            act_varUni_M(:,jj,:) = reshape(act_var_uni(:,:,:,(jj-1)*nIMG+1:(jj)*nIMG),numNeuron,nIMG);                             % reshape response of all neurons to all images on untrained AlexNet
        end
        Cell_act_var{1,ii} = act_var_M; Cell_act_var{2,ii} = act_varUni_M;
    end
    toc
    clearvars act act_rand act_var net_var 
    
    %% Step 4. Finding selective neuron to each class
    disp('Step4: Find selective neuron to each class ... (~ 4 min)');
    tic
    %%% Step4-1: Find selective neuron to each class in pretrained AlexNet
    [~,cellSC] = max(mean(act_M,3),[],2); [cellSB,~] = findSelCell(act_M,nCLS,cellSC,pThr,0);  %test whether cell is significantly selective or not
    face_SB = cellSB'.*(cellSC==indFace); IND_pre = find(face_SB);
    
    %%% Step4-2: Find selective neuron to each class in untrained AlexNet
    [~,cellSC] = max(mean(act_rand_M,3),[],2); [cellSB,~] = findSelCell(act_rand_M,nCLS,cellSC,pThr,0);  %test whether cell is significantly selective or not
    face_SB = cellSB'.*(cellSC==indFace); IND_rand = find(face_SB);
    Cell_IND = {IND_pre;IND_rand};
    
    %%% Step4-3: Find selective neuron to each class in randomly initialized AlexNet
    Cell_IND_var = cell(2,length(stdArray)); 
    for ii = 1:length(stdArray)
        act_var_M = Cell_act_var{1,ii}; act_varUni_M = Cell_act_var{2,ii};
        [~,cellSC] = max(mean(act_var_M,3),[],2); [cellSB,~] = findSelCell(act_var_M,nCLS,cellSC,pThr,0);  %test whether cell is significantly selective or not
        face_SB = cellSB'.*(cellSC==indFace); IND_var = find(face_SB);
        [~,cellSC] = max(mean(act_varUni_M,3),[],2); [cellSB,~] = findSelCell(act_varUni_M,nCLS,cellSC,pThr,0);  %test whether cell is significantly selective or not
        face_SB = cellSB'.*(cellSC==indFace); IND_varUni = find(face_SB);
        Cell_IND_var{1,ii} = IND_var; Cell_IND_var{2,ii} = IND_varUni;
    end
    toc
    
    %% Step 5. Measuring face-selectivity of each neurons
    tic
    disp('Step5: Measure selectivity of face selctive neurons ... (~ 10 sec)')
    %%% Step5-1: Measure selectivity of face selctive neurons in pretrained AlexNet
    act_Mnorm = act_M - mean(act_M(:,nCLS,:),3);
    act_MATnorm = reshape(permute(act_Mnorm(:,[1:nCLS],:),[1,3,2]),numNeuron,(nCLS)*nIMG); act_MATnorm = act_MATnorm./max(act_MATnorm,[],2);
    act_Mnorm_re = zeros(numNeuron,nCLS,nIMG); 
    for ii = 1:nCLS; act_Mnorm_re(:,ii,:) = reshape(act_MATnorm(:,(ii-1)*nIMG+1:(ii)*nIMG),numNeuron,nIMG); end
    [SI_pre] = fun_measureSEL(act_Mnorm_re,nCLS,nIMG,indFace);
    
    %%% Step5-2: Measure selectivity of face selctive neurons in untrained AlexNet
    act_Mnorm = act_rand_M - mean(act_rand_M(:,nCLS,:),3);
    act_MATnorm = reshape(permute(act_Mnorm(:,[1:nCLS],:),[1,3,2]),numNeuron,(nCLS)*nIMG); act_MATnorm = act_MATnorm./max(act_MATnorm,[],2);
    act_Mnorm_re = zeros(numNeuron,nCLS,nIMG);
    for ii = 1:nCLS; act_Mnorm_re(:,ii,:) = reshape(act_MATnorm(:,(ii-1)*nIMG+1:(ii)*nIMG),numNeuron,nIMG); end
    [SI_rand] = fun_measureSEL(act_Mnorm_re,nCLS,nIMG,indFace);
    Cell_SI = {SI_pre;SI_rand};
    
    %%% Step5-3: Measure selectivity of face selctive neurons in initialized AlexNet
    Cell_SI_var = cell(2,length(stdArray));
    for ii = 1:length(stdArray)
        act_var_M = Cell_act_var{1,ii};
        act_Mnorm = act_var_M - mean(act_var_M(:,nCLS,:),3);
        act_MATnorm = reshape(permute(act_Mnorm(:,[1:nCLS],:),[1,3,2]),numNeuron,(nCLS)*nIMG); act_MATnorm = act_MATnorm./max(act_MATnorm,[],2);
        act_Mnorm_re = zeros(numNeuron,nCLS,nIMG);
        for jj = 1:nCLS; act_Mnorm_re(:,jj,:) = reshape(act_MATnorm(:,(jj-1)*nIMG+1:(jj)*nIMG),numNeuron,nIMG); end
        [SI_var] = fun_measureSEL(act_Mnorm_re,nCLS,nIMG,indFace); Cell_SI_var{1,ii} = SI_var;
        
        act_varUni_M = Cell_act_var{2,ii};
        act_Mnorm = act_varUni_M - mean(act_varUni_M(:,nCLS,:),3);
        act_MATnorm = reshape(permute(act_Mnorm(:,[1:nCLS],:),[1,3,2]),numNeuron,(nCLS)*nIMG); act_MATnorm = act_MATnorm./max(act_MATnorm,[],2);
        act_Mnorm_re = zeros(numNeuron,nCLS,nIMG);
        for jj = 1:nCLS; act_Mnorm_re(:,jj,:) = reshape(act_MATnorm(:,(jj-1)*nIMG+1:(jj)*nIMG),numNeuron,nIMG); end
        [SI_varUni] = fun_measureSEL(act_Mnorm_re,nCLS,nIMG,indFace); Cell_SI_var{2,ii} = SI_varUni;
    end
    toc
    
    %% Step 6. Analyzing and showing results
    % Network : Cell_net,Cell_net_var
    % Index of face-neuron : Cell_IND,Cell_IND_var
    % Face-selectivity index : Cell_SI,Cell_SI_var
    
    %% Figure 0 : Showing stimulus dataset
    disp('Showing stimulus ... (~ 2 sec)')
    tic
    imagesPerClass = 10;
    imagesInMontage = cell(nCLS,imagesPerClass);
    for cc = 1:nCLS
        idx = find(double(imd.Labels) == cc);
        ind_pick = idx(randperm(length(idx),imagesPerClass));
        for ii = 1:imagesPerClass
            imagesInMontage{cc,ii} = imread(imds.Files{ind_pick(ii)});
        end
    end
    figure
    montage({imagesInMontage{:}},'Size',[imagesPerClass,nCLS]);
    toc
    title('Face vs non-face dataset (Supplementary Figure.1)','FontSize',15)
end

if flg1 == 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Result 1 : Face-selectivity in pre-trained / untrained AlexNet (Figure 1)
disp('Figure 1 ... (~ 5 sec)')
tic
Result1;
toc
end

if flg2 == 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Result 2 : Preferred feature image on untrained AlexNet
disp('Figure 2 ... (~ 1 min)')
tic
% Decide the simulation type
% 1 : Fast version of PFI simulation. The saved PFI would be displayed.
% 2 : Actual calculation process would be run. It takes around 10 minutes.
Sim = 1;
Result2;
toc
end

if flg3 == 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Result 3 : Face vs non-face discrimination task on untrained AlexNet 
disp('Figure 3 ... (~ 1 min)')
tic
Result3;
toc
end

if flg4 == 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Result 4 : Layer-dependent viewpoint invariance in untrained AlexNet 
disp('Figure 4-5 ... (~ 1.5 min)')
tic
Result4;
toc
end




