%% Result 1 : Face-selectivity in pre-trained / untrained AlexNet 
fontSize_title = 15; fontSize_label = 15; fontSize_legend = 12; 

%% Figure 1d: Response matrix of face-selective neurons in pretrained AlexNet 
act_M = Cell_act{1,1}; IND_face =  Cell_IND{1,1}; 
act_MAT = reshape(permute(act_M(IND_face,[nCLS,1:nCLS-1],:),[1,3,2]),length(IND_face),(nCLS)*nIMG);
act_MATnorm = act_MAT./mean(act_MAT,2); [~,orderTop] = sort(sum(act_MATnorm(:,nIMG+1:2*nIMG),2),'descend'); 
act_MATnormRe = zeros(round(numel(act_MATnorm)/nIMG/nCLS),nCLS,nIMG);
for ii = 1:nCLS
    act_MATnormRe(:,ii,:) = reshape(act_MATnorm(:,(ii-1)*nIMG+1:(ii)*nIMG),round(numel(act_MATnorm)/nIMG/nCLS),nIMG);    
end
act_MATnormRe = act_MATnormRe - act_MATnormRe(:,1,:); 

figure('units','normalized','outerposition',[0 0 0.5 1]);
h1 = subplot(2,1,1);
imagesc(act_MATnorm(orderTop,:)); colormap(h1,hot); caxis([0 10]); set(gca,'TickDir','out');colorbar;
for ii = 1:nCLS-1;hold on;line([nIMG*ii nIMG*ii],[1 length(IND_face)],'Color','w','LineStyle','-');end
xlabel('Image Index','FontSize',fontSize_label); ylabel('Neuron Index','FontSize',fontSize_label);
title('Face-selective response in pretrained AlexNet (Figure 1d)','FontSize',fontSize_label)

h2 = subplot(2,1,2);
SI = Cell_SI{1,1}; SI = SI(IND_face);
[~,order] = sort(SI,'descend'); orderONE = find(SI == 1); 
[~,orderRes] = sort(squeeze(mean(act_MATnormRe(orderONE,2,:),3)),'descend'); 
orderRe = [orderONE(orderRes);order(length(orderONE)+1:end)]; cmap = flip(jet(length(IND_face)),1); 
for ii = length(IND_face):-1:1; idx = orderRe(ii); hold on;plot([0:nCLS+1],[0 mean(act_MATnormRe(idx,:,:),3) 0],'color',cmap(ii,:)); end 
name = STR_LABEL([nCLS,1:nCLS-1]); set(gca, 'XTick', 1:length(name),'XTickLabel',name);xtickangle(45); ylim([-2 8]); set(gca,'TickDir','out')
ylabel('Normalized response','FontSize',fontSize_label);
title('Tuning curves of face-selective neurons in pretrained AlexNet (Figure 1d)','FontSize',fontSize_title) 

%% Figure 1b & e: Weight of the pretrained and untrained AlexNet in each convolutional layer 
net = Cell_net{1,1}; net_rand = Cell_net{2,1};
layers_ind = [2,6,10,12,14]; % target layers: conv1~5
vis_N = 3; % number of filters to visualize
figure('units','normalized','outerposition',[0.1 0 0.5 1])
for ii = 1:length(layers_ind)
    filter_pre = net.Layers(layers_ind(ii)).Weights; ...
        sztmp = size(filter_pre,4); indtmpp=randi(sztmp, [1,vis_N]);                                        % load pre-trained filter
    filter_perm = net_rand.Layers(layers_ind(ii)).Weights; ...
        sztmp_r = size(filter_perm,4); indtmpp_r=randi(sztmp_r, [1,vis_N]);                                 % load permutedre filter
    for jj = 1:length(indtmpp)
        ax=subplot(5,7,7*(ii-1)+jj);
        tmp = squeeze(filter_pre(:,:,1,indtmpp(jj))); caxtmp = max(abs(min(tmp(:))), abs(max(tmp(:))));
        imagesc(squeeze(filter_pre(:,:,1,indtmpp(jj)))); axis image off; %caxis(ax, [-2*caxtmp 2*caxtmp])    % plot pre-trained filter
        if jj == 2; title(['Example Conv',num2str(ii),' filters'],'FontSize',fontSize_legend); end
        ax=subplot(5,7,7*(ii-1)+jj+4);
        tmp = squeeze(filter_perm(:,:,1,indtmpp_r(jj))); caxtmp = max(abs(min(tmp(:))), abs(max(tmp(:))));
        imagesc(squeeze(filter_perm(:,:,1,indtmpp(jj)))); axis image off; %caxis(ax, [-2*caxtmp 2*caxtmp])   % plot permutedre filter
        if jj == 2; title(['Example Conv',num2str(ii),' filters'],'FontSize',fontSize_legend); end
    end
end
sgtitle('Pretrained AlexNet (Left), Untrained AlexNet (Right)','FontSize',fontSize_title);
colormap(gray)

%% Figure 1f: Response matrix of face-selective neurons in untrained AlexNet 
act_M = Cell_act{2,1}; IND_face =  Cell_IND{2,1}; 
act_MAT = reshape(permute(act_M(IND_face,[nCLS,1:nCLS-1],:),[1,3,2]),length(IND_face),(nCLS)*nIMG);
act_MATnorm = act_MAT./mean(act_MAT,2); [~,orderTop] = sort(sum(act_MATnorm(:,nIMG+1:2*nIMG),2),'descend'); 
act_MATnormRe = zeros(round(numel(act_MATnorm)/nIMG/nCLS),nCLS,nIMG);
for ii = 1:nCLS
    act_MATnormRe(:,ii,:) = reshape(act_MATnorm(:,(ii-1)*nIMG+1:(ii)*nIMG),round(numel(act_MATnorm)/nIMG/nCLS),nIMG);    
end
act_MATnormRe = act_MATnormRe - act_MATnormRe(:,1,:); 

figure('units','normalized','outerposition',[0.2 0 0.5 1]);
h1 = subplot(2,1,1);
imagesc(act_MATnorm(orderTop,:)); colormap(h1,hot); caxis([0 5]); set(gca,'TickDir','out');colorbar;
for ii = 1:nCLS-1;hold on;line([nIMG*ii nIMG*ii],[1 length(IND_face)],'Color','w','LineStyle','-');end
xlabel('Image Index','FontSize',fontSize_label); ylabel('Neuron Index','FontSize',fontSize_label);
title('Face-selective response in untrained AlexNet (Figure 1f)','FontSize',fontSize_label)

h2 = subplot(2,1,2);
SI = Cell_SI{2,1}; SI = SI(IND_face);
[~,order] = sort(SI,'descend'); orderONE = find(SI == 1); 
[~,orderRes] = sort(squeeze(mean(act_MATnormRe(orderONE,2,:),3)),'descend'); 
orderRe = [orderONE(orderRes);order(length(orderONE)+1:end)]; cmap = flip(jet(length(IND_face)),1); 
for ii = length(IND_face):-1:1; idx = orderRe(ii); hold on;plot([0:nCLS+1],[0 mean(act_MATnormRe(idx,:,:),3) 0],'color',cmap(ii,:)); end 
name = STR_LABEL([nCLS,1:nCLS-1]); set(gca, 'XTick', 1:length(name),'XTickLabel',name);xtickangle(45); ylim([-2 8]); set(gca,'TickDir','out')
ylabel('Normalized response','FontSize',fontSize_label);
title('Tuning curves of face-selective neurons in untrained AlexNet (Figure 1f)','FontSize',fontSize_title) 

%% Figure 1g : Face-selectivity index in trained / untrained AlexNet 
figure('units','normalized','outerposition',[0.3 0 0.5 1]);
SI_pre = Cell_SI{1,1}; SI_rand = Cell_SI{2,1}; edge = [0:0.05:1];
SI_pre =  SI_pre(Cell_IND{1,1});  SI_rand =  SI_rand(Cell_IND{2,1}); 
hold on 
histogram(SI_pre,edge,'normalization','probability','FaceColor','k')
histogram(SI_rand,edge,'normalization','probability','FaceColor','r')
line([mean(SI_pre) mean(SI_pre)],[0 0.7],'color','k','linestyle','--')
line([mean(SI_rand) mean(SI_rand)],[0 0.7],'color','r','linestyle','--')
xlabel('Face-selectivity index (FSI)','FontSize',fontSize_label); ylabel('Proportion','FontSize',fontSize_label);
title('Face-selectivity index in pretrained AlexNet and untrained (Figure 1g)','FontSize',fontSize_label)
legend('Pretrained','Untrained','Mean FSI of pretrained','Mean FSI of untrained','location','northwest','FontSize',fontSize_legend)

%% Figure 1h-i : Face-selectivity index and number of face neuron across weigth variation
array_meanFSI = zeros(size(Cell_SI_var)); array_stdFSI = zeros(size(Cell_SI_var)); array_Num = zeros(size(Cell_IND_var)); 
for ii = 1:size(Cell_SI_var,1)
    for jj = 1:size(Cell_SI_var,2)
        ind = Cell_IND_var{ii,jj}; si = Cell_SI_var{ii,jj};
        array_Num(ii,jj) = length(ind);
        array_meanFSI(ii,jj)  = mean(si(ind));
        array_stdFSI(ii,jj)  = std(si(ind));
    end
end
figure('units','normalized','outerposition',[0.4 0 0.5 1]);
subplot(2,1,1)
hold on; 
errorbar([1:size(Cell_SI_var,2)],array_meanFSI(2,:),array_stdFSI(2,:),'-ob')
errorbar([1:size(Cell_SI_var,2)],array_meanFSI(1,:),array_stdFSI(1,:),'-or')
xlim([0.5 size(Cell_SI_var,2)+0.5]); xticks([1:size(Cell_SI_var,2)]); xticklabels({'50','100','150'});ylim([-0.2 1.2]);
xlabel('Weight variation (%)','FontSize',fontSize_label); ylabel('Face-selectivity index (FSI)','FontSize',fontSize_label);
title('Tuning of face-neurons across weigth variation (Figure 1g)','FontSize',fontSize_label)
legend('Uniform','Gaussian','location','southeast','FontSize',fontSize_legend)
subplot(2,1,2)
hold on; 
plot([1:size(Cell_SI_var,2)],array_Num(2,:),'-ob')
plot([1:size(Cell_SI_var,2)],array_Num(1,:),'-or')
xlim([0.5 size(Cell_SI_var,2)+0.5]); xticks([1:size(Cell_SI_var,2)]); xticklabels({'50','100','150'}); ylim([0 1500]);
xlabel('Weight variation (%)','FontSize',fontSize_label); ylabel('Counts','FontSize',fontSize_label);
title('Tuning of face-neurons across weigth variation (Figure 1g)','FontSize',fontSize_label)
title('Number of face-neurons across weigth variation (Figure 1g)','FontSize',fontSize_label)