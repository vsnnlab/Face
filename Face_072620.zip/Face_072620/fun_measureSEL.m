function [SI] = fun_measureSEL(act_M,nCLS,nIMG,trgCLS)

R_pre = squeeze(act_M(:,trgCLS,:));
ind_rest = setdiff(1:nCLS-1,trgCLS);
R_nonpre = reshape(act_M(:,ind_rest,:),size(act_M,1),length(ind_rest)*nIMG);

% Selectivity index
SI = (mean(R_pre,2)-mean(R_nonpre,2))./(mean(R_pre,2)+mean(R_nonpre,2));
SI(find((mean(R_pre,2)>0)&(mean(R_nonpre,2)<0))) = 1;
SI(find((mean(R_pre,2)<0)&(mean(R_nonpre,2)>0))) = -1;

end