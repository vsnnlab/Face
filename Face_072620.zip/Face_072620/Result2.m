%% Result 2 : Preferred feature image on untrained AlexNet
fontSize_title = 15; fontSize_label = 15; fontSize_legend = 12; 
%% Simulation
if Sim == 1
    load('PFI_sample.mat')
    figure
    imagesc(PFI_mat(:,:,end));
    axis image off; 
    colormap gray; caxis([0 255]);
    title('Perferred feature image of face-neuron (Figure 2b)','FontSize',fontSize_title)
elseif Sim == 2
    net_rand = Cell_net{2,1}; IND_face = Cell_IND{2,1};
    % Stimulus parameters
    N_image = 2500;         % Number of stimulus images
    iteration = 50;         % Number of iteration
    img_size = 227;         % Image size
    dot_size = 5;           % Size of 2D Gaussian filter
    
    % Generate 2D Gaussian filters
    [pos_xx,pos_yy] = meshgrid(linspace(1+dot_size,img_size-dot_size,sqrt(N_image)),linspace(1+dot_size,img_size-dot_size,sqrt(N_image)));
    pos_xy_list = pos_xx(:) + 1i*pos_yy(:);
    [xx_field,yy_field] = meshgrid(1:img_size,1:img_size); xy_field = xx_field + 1i*yy_field;
    
    img_list = zeros(img_size,img_size,3,length(pos_xy_list));
    count = 1;
    for pp = 1:length(pos_xy_list)
        pos_tmp = pos_xy_list(pp);
        img_tmp = repmat(exp(-(abs(xy_field-pos_tmp).^2)/2/dot_size.^2)*0.5,1,1,3);
        img_list(:,:,:,count) = -img_tmp;
        count = count + 1;
    end
    Gau_stimulus = cat(4,img_list,-img_list);
    
    % Iterative PFI calculation
    PFI = zeros(img_size,img_size,3)+255/2;                                         %Initial PFI
    PFI_mat = zeros(img_size,img_size,iteration+1); PFI_mat(:,:,1) = PFI(:,:,1);
    
    for iter = 1:iteration
        tic
        PFI_0 = PFI; % Save previous PFI
        
        % Generate stimulus as a summation of previous PFI and gaussian stimulus
        IMG = repmat(PFI/255,[1,1,1,size(Gau_stimulus,4)])+Gau_stimulus;
        IMG = uint8(IMG*255);     IMG(IMG<0) = 0; IMG(IMG>255) = 255;
        
        % Measure the response of random AlexNet
        act_rand = activations(net_rand,IMG,'relu5');       % Response of 'relu5' layer in random AlexNet
        act_reshape = reshape(act_rand,43264,size(IMG,4));  % Reshape the response in 2D form
        act_reshape_sel = act_reshape(IND_face,:);          % Find the response of face-selective neurons
        mean_act = mean(act_reshape_sel,1);                 % Average response of face-selective neurons
        
        % Calculate the PFI
        norm_act_reshape = repmat(permute(mean_act-min(mean_act),[1,3,4,2]),img_size,img_size,3);
        PFI = sum(norm_act_reshape.*double(IMG),4)/sum(mean_act-min(mean_act));
        PFI_diff = PFI-PFI_0; PFI = PFI_0 + PFI_diff*10;
        PFI(PFI<0) = 0; PFI(PFI>255) = 255;
        PFI_mat(:,:,iter+1) = PFI(:,:,1);
        toc
    end
    figure;
    imagesc(PFI_mat(:,:,end));
    caxis([0 255]);
    colormap gray; title('Perferred feature image of face-neuron (Figure 2b)','FontSize',fontSize_title)
    axis image off;
end
