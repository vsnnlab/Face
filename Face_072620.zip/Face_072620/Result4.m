%% Result 4 : Layer-dependent viewpoint invariance in untrained AlexNet 
fontSize_title = 15; fontSize_label = 15; fontSize_legend = 12; 

nIMG_view = 10;                                                                                              % number of images on each viewpoint class in the dataset
nCLS_view = 5;                                                                                              % number of total viewpoint classes in the dataset
dir_img_view = 'Dataset_view';                                                                              % set data directory list of viewpoint class names
imd_view = imageDatastore(dir_img_view,'IncludeSubfolders',true,'LabelSource','foldernames');               % load image dataset
imds_view = augmentedImageDatastore([inpSize inpSize 1],imd_view,'ColorPreprocessing','gray2rgb');          % resize image dataset
% array_ViewClass = imd_view.Labels;
tic
net_rand = Cell_net{2,1}; Cell_IND_layer = cell(3,1); Cell_act_layer = cell(3,2); Cell_SI_layer = cell(3,1); Cell_VI_layer = cell(3,1);
for ll = 1:3
    indLayer = ll+2;
    %% Find face-neuron and measure FSI 
    if ll == 3
        Cell_IND_layer{ll,1} = Cell_IND{2,1}; Cell_act_layer{ll,1} = Cell_act{2,1}; Cell_SI_layer{ll,1} = Cell_SI{2,1}; numNeuron = numel(Cell_act{2,1})/nIMG/nCLS;
    else
        % Mesaure activation
        act_rand = activations(net_rand,imds,layersSet{indLayer}); numNeuron = numel(act_rand)/nIMG/nCLS; act_rand_M = zeros(numNeuron,nCLS,nIMG);
        for ii = 1:nCLS; act_rand_M(:,ii,:) = reshape(act_rand(:,:,:,(ii-1)*nIMG+1:(ii)*nIMG),numNeuron,nIMG);end; Cell_act_layer{ll,1} = act_rand_M;
        % Find face-neuron
        [~,cellSC] = max(mean(act_rand_M,3),[],2); [cellSB,~] = findSelCell(act_rand_M,nCLS,cellSC,pThr,0); face_SB = cellSB'.*(cellSC==indFace); IND_rand = find(face_SB); Cell_IND_layer{ll,1} = IND_rand;
        % Measure face-selectivity index
        act_Mnorm = act_rand_M - mean(act_rand_M(:,nCLS,:),3); act_MATnorm = reshape(permute(act_Mnorm(:,[1:nCLS],:),[1,3,2]),numNeuron,(nCLS)*nIMG); act_MATnorm = act_MATnorm./max(act_MATnorm,[],2);
        act_Mnorm_re = zeros(numNeuron,nCLS,nIMG); for ii = 1:nCLS; act_Mnorm_re(:,ii,:) = reshape(act_MATnorm(:,(ii-1)*nIMG+1:(ii)*nIMG),numNeuron,nIMG); end
        [SI_rand] = fun_measureSEL(act_Mnorm_re,nCLS,nIMG,indFace); Cell_SI_layer{ll,1} = SI_rand;
    end
    
    %% Measure response to viewpoint and invariance index 
    % Mesaure activation to viewpoint
    act_rand_view = activations(net_rand,imds_view,layersSet{indLayer}); act_rand_Mview = zeros(numNeuron,nCLS_view,nIMG_view);
    for ii = 1:nCLS_view; act_rand_Mview(:,ii,:) = reshape(act_rand_view(:,:,:,(ii-1)*nIMG_view+1:(ii)*nIMG_view),numNeuron,nIMG_view);end; Cell_act_layer{ll,2} = act_rand_Mview;
    % Mesaure viewpoint invariance
    Cell_VI_layer{ll} = 1./std(mean(act_rand_Mview,3),[],2);
end
toc

%% Figure 5b : Average tuning curve of face-neurons across network hierarchy
Cell_align_tuning = cell(1,3); 
for ll = 1:3
    act_rand_Mview = Cell_act_layer{ll,2}; IND_face = Cell_IND_layer{ll,1};
    tuning_curve = mean(act_rand_Mview,3); tuning_curve = tuning_curve([IND_face],:); array_align = zeros(length([IND_face]),2*nCLS_view-1);
    for ii = 1:length(IND_face)
        [~,indMax] = max(tuning_curve(ii,:),[],2);
        switch indMax
            case 1
                array_align(ii,[5:9]) = array_align(ii,[5:9])+tuning_curve(ii,1:nCLS_view);
                array_align(ii,[5:-1:1]) = array_align(ii,[5:-1:1])+tuning_curve(ii,1:nCLS_view);
                array_align(ii,5) = array_align(ii,5)/2;
            case 2
                array_align(ii,[4:8]) = array_align(ii,[4:8])+tuning_curve(ii,1:nCLS_view);
                array_align(ii,[6:-1:2]) = array_align(ii,[6:-1:2])+tuning_curve(ii,1:nCLS_view);
                array_align(ii,[4:6]) = array_align(ii,[4:6])/2;
            case 3
                array_align(ii,[3:7]) = array_align(ii,[3:7])+tuning_curve(ii,1:nCLS_view);
                array_align(ii,[7:-1:3]) = array_align(ii,[7:-1:3])+tuning_curve(ii,1:nCLS_view);
                array_align(ii,[3:7]) = array_align(ii,[3:7])/2;
            case 4
                array_align(ii,[2:6]) = array_align(ii,[2:6])+tuning_curve(ii,1:nCLS_view);
                array_align(ii,[8:-1:4]) = array_align(ii,[8:-1:4])+tuning_curve(ii,1:nCLS_view);
                array_align(ii,[4:6]) = array_align(ii,[4:6])/2;
            case 5
                array_align(ii,[1:5]) = array_align(ii,[1:5])+tuning_curve(ii,1:nCLS_view);
                array_align(ii,[9:-1:5]) = array_align(ii,[9:-1:5])+tuning_curve(ii,1:nCLS_view);
                array_align(ii,5) = array_align(ii,5)/2;
        end
    end
    Cell_align_tuning{ll} = array_align;
end

figure('units','normalized','outerposition',[0 0 0.5 1]); hold on 
h1 = plot([-180:45:180],mean(Cell_align_tuning{1}./30,1)+(1-mean(mean(Cell_align_tuning{1}./30,1))),'k');
shadedErrorBar([-180:45:180],mean(Cell_align_tuning{1}./30,1)+(1-mean(mean(Cell_align_tuning{1}./30,1))),std(Cell_align_tuning{1},1)./length(sqrt(Cell_align_tuning{1})),'lineprops',{'k','markerfacecolor','k'});
h2 = plot([-180:45:180],mean(Cell_align_tuning{2}./30,1)+(1-mean(mean(Cell_align_tuning{2}./30,1))),'b');
shadedErrorBar([-180:45:180],mean(Cell_align_tuning{2}./30,1)+(1-mean(mean(Cell_align_tuning{2}./30,1))),std(Cell_align_tuning{2},1)./length(sqrt(Cell_align_tuning{2})),'lineprops',{'b','markerfacecolor','b'});
h3 = plot([-180:45:180],mean(Cell_align_tuning{3}./30,1)+(1-mean(mean(Cell_align_tuning{3}./30,1))),'r');
shadedErrorBar([-180:45:180],mean(Cell_align_tuning{3}./30,1)+(1-mean(mean(Cell_align_tuning{3}./30,1))),std(Cell_align_tuning{3},1)./length(sqrt(Cell_align_tuning{3})),'lineprops',{'r','markerfacecolor','r'});
xlim([-180 180]); xticks([-180 -90 0 90 180]); ylim([0.5 1.5]);ylabel('Normalized response','FontSize',fontSize_label);
title('Layer-dependent response (Figure 5b)','FontSize',fontSize_label)
legend([h1 h2 h3],'3layer' ,'4layer', '5layer','location','northeast','FontSize',fontSize_legend)
xlabel('Angle difference (deg)','FontSize',fontSize_label);

%% Figure 5d : View invariance of face-neurons across network hierarchy
array_meanVI = zeros(1,3); array_stdVI = zeros(1,3); VIthr = 2;
for ii = 1:3
    VI = Cell_VI_layer{ii}; IND_face = Cell_IND_layer{ii}; VI = VI(IND_face); VI(VI>VIthr) = [];
    array_meanVI(ii) = mean(VI); array_stdVI(ii) = std(VI);
end

figure('units','normalized','outerposition',[0.5 0 0.5 1]); 
errorbar([1:3],array_meanVI,array_stdVI,'-ok');
xticks([1:3]); xlim([0.5 3.5]); xticklabels({'Conv3','Conv4','Conv5'});
ylabel('View invariance','FontSize',fontSize_label);
title('Layer-dependent invariance (Figure 5d)','FontSize',fontSize_label);